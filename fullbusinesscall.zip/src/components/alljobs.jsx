import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEdit, faTrashAlt } from '@fortawesome/free-solid-svg-icons'
import './styles.css'
import { useAppContext } from '../context/AppContext'
import Loader from './Loader'

export default function AllJobs() {
  const navigate = useNavigate()
  const [jobs, setJobs] = useState([])
  const [loading, setLoading] = useState(true)
  const { fetchCollection, deleteDocument } = useAppContext()

  const getJobs = async () => {
    setLoading(true)
    const jobs = await fetchCollection('jobs')
    setJobs(jobs)
    setLoading(false)
  }

  useEffect(() => {
    getJobs()
  }, [])

  const handleEditJob = (id) => {
    navigate(`/edit-job/${id}`)
  }

  const handleDeleteJob = async (id) => {
    await deleteDocument('jobs', id)
    setJobs(jobs.filter((job) => job.id !== id))
    getJobs()
  }

  if (loading) {
    return <Loader />
  }

  return (
    <div className="container-fluid p-4 h-100 m-2">
      <div className="p-4">
        <h1 className="fw-bold mb-4">All Jobs</h1>
        <div className="table-container mt-4">
          <table className="table table-bordered table-hover mt-4">
            <thead className="thead-dark">
              <tr>
                <th>#</th>
                <th>Job Name</th>
                <th>Keywords</th>
                <th>Location</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {jobs.map((job) => (
                <tr key={job.id}>
                  <td>{job.id}</td>
                  <td>{job?.job_name}</td>
                  <td>{job?.keywords}</td>
                  <td>{job?.location_info?.address}</td>
                  <td>
                    <button
                      className="btn btn-primary btn-sm me-2"
                      onClick={() => handleEditJob(job.id)}
                    >
                      <FontAwesomeIcon icon={faEdit} /> Edit
                    </button>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => handleDeleteJob(job.id)}
                    >
                      <FontAwesomeIcon icon={faTrashAlt} /> Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
