import React from 'react'
import './loader.css'

const Loader = () => {
  return (
    <div className="loader-overlay">
      <div className="spinner"></div>
    </div>
  )
}

export default Loader
