import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEdit, faTrashAlt } from '@fortawesome/free-solid-svg-icons'
import './styles.css'
import MainLayout from './mainlayout'
import { useAppContext } from '../context/AppContext'
import Loader from './Loader'

export default function AllServices() {
  const { fetchCollection, deleteDocument } = useAppContext()
  const [services, setServices] = useState([])
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  const getServices = async () => {
    setLoading(true)
    const services = await fetchCollection('services')
    setServices(services)
    setLoading(false)
  }

  const handleEditService = (id) => {
    navigate(`/edit-service-product/${id}`)
  }

  const handleDeleteServices = async (id) => {
    await deleteDocument('services', id)
    setServices(services.filter((service) => service.id !== id))
    getServices()
  }

  useEffect(() => {
    getServices()
  }, [])

  if (loading) {
    return <Loader />
  }

  return (
    <div className="container-fluid p-4 h-100 m-2">
      <div className="p-4">
        <h1 className="fw-bold  mb-4">All Services or Products</h1>
        <div className="table-container mt-4">
          <table className="table table-bordered table-hover">
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Keywords</th>
                <th>Location</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {services.map((service) => (
                <tr key={service.id}>
                  <td>{service.id}</td>

                  <td>{service.business_name}</td>
                  <td>{service.keywords}</td>
                  <td>{service.location_info.address}</td>
                  <td>
                    <button
                      className="btn btn-primary btn-sm me-2"
                      onClick={() => handleEditService(service.id)}
                    >
                      <FontAwesomeIcon icon={faEdit} /> Edit
                    </button>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => handleDeleteServices(service.id)}
                    >
                      <FontAwesomeIcon icon={faTrashAlt} /> Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
